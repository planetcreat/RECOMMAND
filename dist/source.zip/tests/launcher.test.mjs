import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {boot} from './harness.mjs';import {launcherHarness} from './launcher-harness.mjs';
test('isolated QA launcher and chapter share a namespace and leave real saves and briefing flags intact',()=>{
 const h=launcherHarness({seenAll:true,qaScope:'motion-review'});h.buttons[0].onclick();
 assert.equal(h.elements.briefing.open,true);h.elements.briefSkip.onclick();
 assert.match(h.elements.gameFrame.srcdoc,/data-qa-scope="motion-review"/);
 assert.match(h.elements.gameFrame.srcdoc,/const localStorage=\(function createScopedStorage/);
 assert.equal(h.storage.get('recommand-save-v1'),'existing-user-save');
 assert(h.storage.has('recommand-qa:motion-review:recommand-briefing-v1'));
 assert.match(h.elements.qaNotice.textContent,/기존 플레이 기록과 분리/);
});
test('offline launcher shares its bundled Jua font with each chapter',()=>{
 const h=launcherHarness({seenAll:true});
 assert.equal((h.html.match(/data:font\/ttf;base64,/g)||[]).length,1);
 const font=h.elements.uiFont.textContent;
 assert.match(font,/font-family: "Jua"/);
 assert.match(font,/SIL OPEN FONT LICENSE/);
 const bytes=font.match(/data:font\/ttf;base64,([A-Za-z0-9+/=]+)/)[1];
 assert(Buffer.from(bytes,'base64').equals(fs.readFileSync(new URL('../dist/assets/Jua-Regular.ttf',import.meta.url))));
 for(const button of h.buttons){
  button.onclick();
  assert(h.elements.gameFrame.srcdoc.includes('<style id="uiFont">'+font+'</style>'));
  assert(!h.elements.gameFrame.srcdoc.includes('__RECOMMAND_UI_FONT_CSS__'));
 }
});
test('software renderer is gated by a valid QA scope and is carried to every chapter',()=>{
 const h=launcherHarness({search:'?qa=garden-soft&renderer=software'});
 for(const button of h.buttons){
  button.onclick();h.elements.briefSkip.onclick();
  assert.match(h.elements.gameFrame.srcdoc,/<html data-qa-scope="garden-soft" data-qa-renderer="software"/);
 }
 assert.match(h.elements.qaNotice.textContent,/CPU 3D/);
 assert.equal(h.storage.get('recommand-save-v1'),'existing-user-save');
 for(const search of ['?renderer=software','?qa=garden-soft','?qa=garden-soft&renderer=software&renderer=software']){
  const launch=launcherHarness({search,seenAll:true});
  launch.buttons[0].onclick();
  if(launch.elements.briefing.open)launch.elements.briefSkip.onclick();
  assert.doesNotMatch(launch.elements.gameFrame.srcdoc,/<html[^>]*data-qa-renderer/);
 }
 assert.throws(()=>launcherHarness({search:'?qa=&renderer=software'}),/Invalid QA save scope/);
});

test('chapter renderer startup honours QA forcing and still falls back if WebGL fails',()=>{
 for(const [file,rendererName,endMarker] of [
  ['RECOMMAND.html','R','const terrainRand'],
  ['SWAEHAE.html','seaRenderer','const seaArt'],
  ['MUMYEONG.html','lateRenderer','const lateSoft'],
  ['HWANSEONG.html','lateRenderer','const lateSoft']
 ]){
  const html=fs.readFileSync(new URL('../release/'+file,import.meta.url),'utf8');
  const start=html.indexOf('let '+rendererName+';'),end=html.indexOf(endMarker,start);
  assert(start>=0&&end>start,file);
  for(const [forced,webglFails,expectedAttempts,expectedBackend] of [
   [true,false,0,'software'],[false,false,1,'webgl'],[false,true,1,'software']
  ]){
   let attempts=0,replacements=0;
   const lookup=()=>({replaceWith(){replacements++;}});
   const box={
    $:lookup,el:lookup,lateEl:lookup,lateConfig:{name:'test'},
    document:{documentElement:{dataset:forced?{qaRenderer:'software'}:{}},createElement:()=>({setAttribute(){}})},
    Renderer:class{constructor(){attempts++;if(webglFails)throw Error('WebGL unavailable');}},
    SoftwareRenderer:class{constructor(){this.backend='software';}}
   };
   const renderer=vm.runInNewContext(html.slice(start,end)+'\n'+rendererName,box);
   assert.equal(attempts,expectedAttempts,file);
   assert.equal(renderer.backend,expectedBackend,file);
   assert.equal(replacements,expectedBackend==='software'?1:0,file);
  }
 }
});

test('single-file launcher parses, switches both embedded chapters and reports ready/errors',()=>{
 const html=fs.readFileSync(new URL('../release/PLAY-RECOMMAND.html',import.meta.url),'utf8'),code=html.match(/<script>([\s\S]*?)<\/script>/)[1];new vm.Script(code);
 const {elements,events,buttons}=launcherHarness({seenAll:true});
 buttons[0].onclick();let child=elements.gameFrame.srcdoc;assert(child.includes('parent.postMessage'));assert(!child.includes("location.href='SWAEHAE.html'"));assert(!/<script[^>]+src=|<link[^>]+href=/i.test(child));
 for(const m of child.matchAll(/<script(?: type="module")?>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);
 events.message({source:{},data:{type:'recommand-switch',chapter:'swaehae'}});assert.equal(elements.gameFrame.srcdoc,child);
 events.message({source:elements.gameFrame.contentWindow,data:{type:'recommand-switch',chapter:'swaehae'}});child=elements.gameFrame.srcdoc;assert(!/<script[^>]+src=|<link[^>]+href=/i.test(child));
 for(const m of child.matchAll(/<script(?: type="module")?>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);
 events.message({source:elements.gameFrame.contentWindow,data:{type:'recommand-child-ready',chapter:'swaehae'}});assert.equal(elements.launcherStatus.hidden,true);
 events.message({source:elements.gameFrame.contentWindow,data:{type:'recommand-child-error',chapter:'swaehae',message:'test error'}});assert.equal(elements.launcherStatus.hidden,false);assert.match(elements.loadMessage.textContent,/test error/);
 for(const chapter of ['mumyeong','hwanseong']){events.message({source:elements.gameFrame.contentWindow,data:{type:'recommand-switch',chapter}});const next=elements.gameFrame.srcdoc;assert(next.includes('data-planet=\"'+chapter+'\"'));assert(!next.includes('__RECOMMAND_ASSET_'));assert.equal((next.match(/data:image\/png;base64,/g)||[]).length,3);for(const m of next.matchAll(/<script(?: type=\"module\")?>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);}
 assert.equal((html.match(/data:image\/png;base64,/g)||[]).length,3);
});
test('boot guard shows load errors and clears the error panel when startup succeeds',()=>{
 const listeners={},ids={},root={dataset:{}},body={append(e){ids[e.id]=e;}};const document={documentElement:root,body,querySelector:()=>null,getElementById:id=>ids[id],createElement:()=>({style:{},setAttribute(){},append(...nodes){for(const n of nodes)if(n.id)ids[n.id]=n;},remove(){delete ids[this.id];}})};
 const box={window:{addEventListener:(k,fn)=>listeners[k]=fn},document,location:{protocol:'https:'},setTimeout:()=>1};vm.createContext(box);vm.runInContext(fs.readFileSync(new URL('../dist/boot.js',import.meta.url),'utf8'),box);
 listeners.error({target:{tagName:'SCRIPT'}});assert(ids.loadFailure);assert.match(ids.loadFailureReason.textContent,/PLAY-RECOMMAND/);listeners['recommand-ready']();assert.equal(root.dataset.recommandReady,'true');assert.equal(ids.loadFailure,undefined);
});
test('missing or invalid saves explain failure and never erase the existing save',()=>{
 const h=boot();h.a.start(true);assert.match(h.get('toast').textContent,/저장된 기록이 없습니다/);assert.equal(h.storage.size,0);
 h.storage.set('recommand-save-v1','{broken');h.a.start(true);assert.equal(h.storage.get('recommand-save-v1'),'{broken');assert.match(h.get('toast').textContent,/기록 확인/);
});
