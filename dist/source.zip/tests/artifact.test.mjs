import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import {SoftwareRenderer} from '../dist/software.js';import {lookAt} from '../dist/math.js';
test('software backdrop stays below terrain without taking its default layer',()=>{
 const renderer=Object.create(SoftwareRenderer.prototype),layers=[];
 Object.assign(renderer,{center:[0,0],calls:0,renderChunk:(_,layer)=>layers.push(layer)});
 const data=[0,0,0,1,1,1, 1,0,0,1,1,1, 0,0,1,1,1,1];
 for(const geometry of [{data,softwareLayer:-1},{data},{data}])renderer.mesh(renderer.upload(geometry));
 assert.deepEqual(layers,[-1,0,1]);
});
test('software projection is finite, preserves left/right, and bends distant ground downward',()=>{const r=Object.create(SoftwareRenderer.prototype);Object.assign(r,{view:lookAt([0,18,22],[0,0,-1]),center:[0,0],curve:0,width:1280,height:720,focal:720/(2*Math.tan(Math.PI/6))});const a=r.project(0,0,0),b=r.project(1,0,0),flat=r.project(0,0,-15);assert(b.x>a.x);r.curve=.012;const bent=r.project(0,0,-15);assert(bent.y>flat.y);assert(Object.values(bent).every(Number.isFinite));});
test('standalone artifact parses and has no external scripts or styles',()=>{const html=fs.readFileSync(new URL('../release/RECOMMAND.html',import.meta.url),'utf8');const js=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];new vm.Script(js);assert(!/^import /m.test(js));assert(!/<script[^>]+src=/i.test(html));assert(!/<link[^>]+href=/i.test(html));assert(html.includes('class SoftwareRenderer'));});
test('all statically referenced UI IDs exist or are deliberately dynamic',()=>{const game=fs.readFileSync(new URL('../dist/game.js',import.meta.url),'utf8'),html=fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8'),ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]));for(const m of game.matchAll(/\$\('([^']+)'\)/g))assert(ids.has(m[1])||['choices','importDecision'].includes(m[1]),'Missing UI ID '+m[1]);});

